<?php

define('PROXY', null);
define('COOKIE_FILE', "cookie.txt");
define('COOKIE_FILE2', "cookie2.txt");

function writeOnFile($filePath, $data, $mode = 'w')
{
    $captchaFile = fopen($filePath,$mode);
    fwrite($captchaFile,$data);
    fclose($captchaFile);
}

function readCookieFile($text = "text : ",$len = 10000,$mode = 'r')
{
    $cookie = fopen(COOKIE_FILE,$mode);
    $scookie = fread($cookie ,$len);
    echo $text.$scookie.PHP_EOL;
    fclose($cookie);
}

function recreateNewFile($filePath)
{
    if (file_exists($filePath)) {
        unlink($filePath);
        $cookie = fopen($filePath, 'w');
        fwrite($cookie , '');
        fclose($cookie);
    }
}