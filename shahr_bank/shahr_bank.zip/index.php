<?php

try {

    require_once "./global.php";
    $doc = new DOMDocument();

    $queryParams = getQueryParams();
    $loginData = getLoginData();
    $mainPageHtml = checkLogin();

    if ($mainPageHtml != "") {
        // $balance = getBalance($mainPageHtml, $doc);
        $runWithoutLogin = runWithoutLogin($mainPageHtml, $doc);
        if($runWithoutLogin == true){
            exit;
        }
    }
    recreateNewFile(COOKIE_FILE);

    // first curl for load of login page
    $firstUrl = 'https://ebank.shahr-bank.ir/ebank/login/loginPage.action?ibReq=WEB';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $firstUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Accept: application/json", "Content-Type: application/x-www-form-urlencoded"]);
    curl_setopt($ch, CURLOPT_COOKIEJAR, COOKIE_FILE);
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    $firstResponse = curl_exec($ch); // output: "";

    // second curl for load of login page
    curl_setopt($ch, CURLOPT_URL, 'https://ebank.shahr-bank.ir/ebank/dispatcherNamespace/dispatcherAction.action?ibReq=WEB');
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    $secondResponse = curl_exec($ch);

    // third curl for load of login page
    curl_setopt($ch, CURLOPT_URL, $firstUrl);
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    $thirdResponse = curl_exec($ch); // now whole html loaded
    $loginData['loginToken'] = getInputTag($thirdResponse, $doc, '/<input type="hidden" name="loginToken" value=".*/'); //get current token

    // curl for get captcha
    $captchaUrl = 'https://ebank.shahr-bank.ir/ebank/login/captcha.action?isSoundCaptcha=false';
    curl_setopt($ch, CURLOPT_URL, $captchaUrl);
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    $captchaRawImage = curl_exec($ch);

    if ($captchaRawImage != '') {
        // save captcha image
        writeOnFile('images/captcha.png', $captchaRawImage);

        // get captcha code from user
        $loginData['captcha'] = readline('Enter the captcha:');
        var_dump($loginData);

        // curl for get sms code
        $loginUrl = "https://ebank.shahr-bank.ir/ebank/login/login.action?" . http_build_query($queryParams);
        curl_setopt($ch, CURLOPT_URL, $loginUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($loginData));
        $loginResponse = curl_exec($ch);
        writeOnFile('response/loginResponse.html', $loginResponse);
        if (!$loginResponse) {
            echo "Fail in Login" . PHP_EOL;
            exit;
        }

        $loginData2 = getLoginData2();
        $loginData2["ticketCode"] = readline('Enter the SMS:');

        $loginData2["ticketLoginToken"] = getInputTag($loginResponse, $doc, '/<input type="hidden" name="ticketLoginToken" value=".*/');
        $loginData2["mobileNumber"] = getInputTag($loginResponse, $doc, '/<input type="hidden" class="" name="mobileNumber" id="mobileNumber" value=".*/');
        var_dump($loginData2);

        $loginUrl2 = 'https://ebank.shahr-bank.ir/ebank/login/twoPhaseLoginWithTicket.action?' . http_build_query($queryParams);
        curl_setopt($ch, CURLOPT_URL, $loginUrl2);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($loginData2));
        $loginResponse2 = curl_exec($ch);
        var_dump('res 2:', $loginResponse2);
        writeOnFile('response/loginResponse2.html', $loginResponse2);

        $urlCheckUsername = 'https://ebank.shahr-bank.ir/ebank/login/checkUsername.action';
        curl_setopt($ch, CURLOPT_URL, $urlCheckUsername);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $checkUsernameResponse = curl_exec($ch);
        writeOnFile('response/checkUsernameResponse.html', $checkUsernameResponse);

        $urlCheckPassword = 'https://ebank.shahr-bank.ir/ebank/login/checkPassword.action';
        curl_setopt($ch, CURLOPT_URL, $urlCheckPassword);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $checkPasswordResponse = curl_exec($ch);
        writeOnFile('response/checkPasswordResponse.html', $checkPasswordResponse);

        $urlCompleteLogin = 'https://ebank.shahr-bank.ir/ebank/login/completeLogin.action';
        curl_setopt($ch, CURLOPT_URL, $urlCompleteLogin);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $completeLoginResponse = curl_exec($ch);
        writeOnFile('response/completeLoginResponse.html', $completeLoginResponse);

        $homePageUrl = 'https://ebank.shahr-bank.ir/ebank/home/homePage.action';
        curl_setopt($ch, CURLOPT_URL, $homePageUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $homePageHtml = curl_exec($ch);
        writeOnFile('response/homePageHtml.html', $homePageHtml);
        // $balance = getBalance($homePageHtml, $doc);

        $selectDateUrl = 'https://ebank.shahr-bank.ir/ebank/viewAcc/partialDepositShow.action?daysAgo=30';
        curl_setopt($ch, CURLOPT_URL, $selectDateUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $selectPageHtml = curl_exec($ch);
        writeOnFile('response/selectPageHtml.html', $selectPageHtml);
        
        $balanceData = getBalanceData();
        $balanceData['depositShowToken'] = getInputTag($selectPageHtml, $doc, '/<input type="hidden" name="depositShowToken" value=".*/');
        $balanceData['fromDateTime'] = getInputTag($selectPageHtml, $doc, '/<input type="text" name="fromDateTime" id="fromDateTime" value=".*/');
        $balanceData['toDateTime'] = getInputTag($selectPageHtml, $doc, '/<input type="text" name="toDateTime" id="toDateTime" value=".*/');
        var_dump($balanceData);

        $depositeShowUrl = 'https://ebank.shahr-bank.ir/ebank/viewAcc/depositShow.action?' . http_build_query($balanceData);
        curl_setopt($ch, CURLOPT_URL, $depositeShowUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $depositeShowHtml = curl_exec($ch);
        writeOnFile('response/depositeShowHtml.html', $depositeShowHtml);

        $balance = getBalanceFromDeposite( $depositeShowHtml , $doc);
        writeOnFile('balance.txt', 'Your last balance from Deposite:'.$balance);

        $deposits = getDeposit($depositeShowHtml, $doc);
        var_dump($deposits);

        if(is_array($deposits)){
            $depositsString = implode(",",$deposits);
        }
        writeOnFile('deposits.txt', 'Your history deposite:'.$depositsString);

        curl_close($ch);
    } else {
        echo "It has a problem !!";
    }

} catch (\Exception $e) {
    echo $e->getMessage();
}

function getInputTag(string $html, DOMDocument $doc, string $pattern)
{
    preg_match($pattern, $html, $matches);
    $text = "<html><body>
    $matches[0]
    </body></html>";
    $doc->loadHTML($text);

    $result = null;
    if ($doc->getElementsByTagName("input"))
        $result = $doc->getElementsByTagName("input")[0]->getAttribute("value");
    return $result;
}

function getBalance(string $html, DOMDocument $doc)
{
    preg_match('/<div id="sourceSavingContainerInfo" class="smartComboInfo">.*/', $html, $matches);

    $text = "<html><body>
    $matches[0]
    </body></html>";
    $doc->loadHTML(mb_convert_encoding($text, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    $result = $doc->getElementById("sourceSavingContainerInfo");
    return $result->textContent;
}

function getBalanceFromDeposite(string $html , DOMDocument $doc){
    preg_match('/<table class="datagrid" id="rowTbl">(.*?)<\/table>/s',$html,$matches);
    $text = "<html><body>
    $matches[0]
    </body></html>";
    $doc->loadHTML(mb_convert_encoding($text, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    $trs = $doc->getElementsByTagName("tr");
    return $trs->item(1)->getElementsByTagName("td")->item(6)->textContent;
}

function getDeposit(string $html, DOMDocument $doc)
{
    preg_match('/<table class="datagrid" id="rowTbl">(.*?)<\/table>/s', $html, $matches);
    $text = "<html><body>
    $matches[0]
    </body></html>";
    $doc->loadHTML(mb_convert_encoding($text, 'HTML-ENTITIES', 'UTF-8'), LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
    $trs = $doc->getElementsByTagName("tr");

    for ($i = 1; $trs->count() > $i; $i++) {
        $deposit = $trs->item($i)->getElementsByTagName("td")->item(4)->textContent;
        if (str_contains($deposit, "-")) {
            continue;
        } else {
            $result[] = $deposit;
        }

    }
    return $result;
}

function checkLogin()
{
    $urlHomePage = 'https://ebank.shahr-bank.ir/ebank/home/homePage.action';
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $urlHomePage);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Accept: application/json", "Content-Type: application/x-www-form-urlencoded"]);
    curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
    $result = curl_exec($ch);
    return $result;
}

function getQueryParams()
{
    return [
        'ibReq' => 'WEB',
        'lang' => 'fa',
    ];
}

function getLoginData() :array
{
    return [
        'username' => 'behnam8900',
        'password' => 'D@nyal0118DG@Ss',
        'loginType' => 'STATIC_PASSWORD',
        'isSoundCaptcha' => 'false',
        'otpSyncRequired' => 'false',
        'soundCaptchaEnable' => 'true',
        'struts.token.name' => 'loginToken',
        'hiddenPass1' => '1',
        'hiddenPass2' => '2',
        'hiddenPass3' => '3',
    ];
}

function getLoginData2() :array
{
    return [
        "struts.token.name" => "ticketLoginToken",
        "ticketResendTimerRemaining" => -1,
        "hiddenPass1" => 1,
        "hiddenPass2" => 2,
        "hiddenPass3" => 3,
    ];
}

function getBalanceData() :array
{
    return [
        'struts.token.name' => "depositShowToken",
        // 'depositShowToken' => "PL7VMNHVKWZKM33V5NABJ2L6AG56WADJ",
        'advancedSearch' => true,
        // 'personalityType' => 
        // 'depositGroupByReq' => 
        // 'referenceCustomerName' => 
        // 'referenceCif' => 
        // 'ownershipType' => 
        // 'accountType' => 
        // 'currencyType' => 
        'maxLenForNote' => '200',
        'selectedDeposit' => '4001002408872', //TODO
        'selectedDepositValueType' => 'sourceDeposit',
        // 'selectedDepositPinnedDeposit' => 
        'selectedDepositIsComboValInStore' => false,
        // 'billType' => 
        'fromDateTime' => '1402/01/26  -  00:00',
        'toDateTime' => '1402/02/25  -  11:52',
        // 'minAmount' => 
        // 'currency' => 
        // 'currencyDefaultFractionDigits' => 
        // 'maxAmount' => 
        'order' => 'DESC',
        // 'desc' => 
        // 'paymentId' => 
    ];
}

function runWithoutLogin(string $mainPageHtml, DOMDocument $doc){
        $ch = curl_init();

        $selectDateUrl = 'https://ebank.shahr-bank.ir/ebank/viewAcc/partialDepositShow.action?daysAgo=30';
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Accept: application/json", "Content-Type: application/x-www-form-urlencoded"]);
        curl_setopt($ch, CURLOPT_URL, $selectDateUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $selectPageHtml = curl_exec($ch);
        writeOnFile('response/selectPageHtml.html', $selectPageHtml);
        $balanceData = getBalanceData();
        $balanceData['depositShowToken'] = getInputTag($selectPageHtml, $doc, '/<input type="hidden" name="depositShowToken" value=".*/');
        $balanceData['fromDateTime'] = getInputTag($selectPageHtml, $doc, '/<input type="text" name="fromDateTime" id="fromDateTime" value=".*/');
        $balanceData['toDateTime'] = getInputTag($selectPageHtml, $doc, '/<input type="text" name="toDateTime" id="toDateTime" value=".*/');
        var_dump($balanceData);

        $depositeShowUrl = 'https://ebank.shahr-bank.ir/ebank/viewAcc/depositShow.action?' . http_build_query($balanceData);
        curl_setopt($ch, CURLOPT_URL, $depositeShowUrl);
        curl_setopt($ch, CURLOPT_COOKIEFILE, COOKIE_FILE);
        $depositeShowHtml = curl_exec($ch);

        if($depositeShowHtml == false){
            return $depositeShowHtml;
        }
        writeOnFile('response/depositeShowHtml.html', $depositeShowHtml);

        $balance = getBalanceFromDeposite( $depositeShowHtml , $doc);
        writeOnFile('balance.txt', 'Your last balance from Deposite:'.$balance);

        $deposits = getDeposit($depositeShowHtml, $doc);
        var_dump($deposits);
        var_dump('You have already logged in.');

        if(is_array($deposits)){
            $depositsString = implode(",",$deposits);
        }
        writeOnFile('deposits.txt', 'Your history deposite:'.$depositsString);

        curl_close($ch);
        return true;
}